package com.utn.EjercicioIntegrador1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioIntegrador1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
